import './App.css';
import Header from './Pages/Header';
import Middle from './Pages/Middle';
import Footer from './Pages/Footer';


function App() {
  return (
    <div className="App">
      <div>
       <Header/>
        <Middle/>
        <Footer/>
        
      </div>
    </div>
  );
}

export default App;
